
import React, { useState, useEffect } from 'react';

interface DuaOption {
  id: string;
  arabic: string;
  translation: string;
  target: number;
}

const famousTasbihs: DuaOption[] = [
  { id: '1', arabic: 'سبحان الله', translation: 'Subhan Allah', target: 33 },
  { id: '2', arabic: 'الحمد لله', translation: 'Alhamdulillah', target: 33 },
  { id: '3', arabic: 'الله أكبر', translation: 'Allahu Akbar', target: 34 },
  { id: '4', arabic: 'أستغفر الله', translation: 'Astaghfirullah', target: 100 },
  { id: '5', arabic: 'لا إله إلا الله', translation: 'La ilaha illallah', target: 100 },
  { id: '6', arabic: 'اللهم صل على محمد', translation: 'Durood Sharif', target: 100 },
  { id: '7', arabic: 'لا حول ولا قوة إلا بالله', translation: 'La Hawla wala Quwwata', target: 100 },
  { id: '8', arabic: 'سبحان الله وبحمده', translation: 'SubhanAllahi wa bihamdihi', target: 100 },
  { id: '9', arabic: 'سبحان الله العظيم', translation: 'SubhanAllahi al-Adheem', target: 100 },
  { id: '10', arabic: 'سبحان الله والحمد لله ولا إله إلا الله والله أكبر', translation: '4th Kalimah snippet', target: 100 },
];

const Tasbih: React.FC = () => {
  const [count, setCount] = useState(() => {
    const saved = localStorage.getItem('tasbih_count');
    return saved ? parseInt(saved, 10) : 0;
  });
  const [selectedDua, setSelectedDua] = useState<DuaOption>(famousTasbihs[0]);
  const [goal, setGoal] = useState(selectedDua.target);
  const [sessionTotal, setSessionTotal] = useState(0);

  useEffect(() => {
    localStorage.setItem('tasbih_count', count.toString());
  }, [count]);

  const handleIncrement = () => {
    setCount(prev => prev + 1);
    setSessionTotal(prev => prev + 1);
    
    // Haptic feedback
    if ('vibrate' in navigator) {
      navigator.vibrate(50);
    }

    // Goal reached logic
    if ((count + 1) % goal === 0) {
      if ('vibrate' in navigator) {
        navigator.vibrate([100, 50, 100]);
      }
    }
  };

  const handleReset = () => {
    if (window.confirm('Kya aap count zero karna chahte hain? (Do you want to reset the count?)')) {
      setCount(0);
      setSessionTotal(0);
    }
  };

  const selectDua = (dua: DuaOption) => {
    setSelectedDua(dua);
    setGoal(dua.target);
  };

  return (
    <div className="h-full flex flex-col bg-[#0b1120] animate-fadeIn overflow-hidden">
      {/* Header */}
      <div className="p-6 pb-2 text-center bg-slate-900/50 backdrop-blur-md">
        <h2 className="text-2xl font-bold text-white mb-1">Digital Tasbih</h2>
        <p className="text-amber-500 text-[10px] font-black uppercase tracking-[0.2em]">Zikr-e-Illahi</p>
      </div>

      {/* Improved Dua Selector */}
      <div className="bg-slate-900/30 py-4 border-b border-white/5">
        <div className="px-6 mb-2 flex justify-between items-center">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Select Tasbih</span>
          <span className="text-[10px] font-bold text-indigo-400">← Scroll →</span>
        </div>
        <div className="w-full overflow-x-auto no-scrollbar flex gap-4 px-6 pb-2">
          {famousTasbihs.map((dua) => (
            <button
              key={dua.id}
              onClick={() => selectDua(dua)}
              className={`flex-shrink-0 px-6 py-4 rounded-[2rem] transition-all border-2 flex flex-col items-center justify-center min-w-[160px] ${
                selectedDua.id === dua.id 
                  ? 'bg-gradient-to-br from-amber-500 to-orange-600 border-amber-400 text-white shadow-xl shadow-amber-500/30 scale-105' 
                  : 'bg-slate-800/80 border-white/5 text-slate-400 hover:bg-slate-700'
              }`}
            >
              <p className="quran-font text-xl mb-1 leading-tight whitespace-nowrap">{dua.arabic}</p>
              <p className="text-[9px] font-black uppercase tracking-tighter opacity-70">{dua.translation}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Main Counter Display */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 relative">
        {/* Large Arabic Text in background/center */}
        <div className="absolute top-10 text-center w-full px-10 pointer-events-none transition-all duration-500">
           <p className="quran-font text-4xl text-white/20 leading-relaxed">
              {selectedDua.arabic}
            </p>
        </div>

        <button
          onClick={handleIncrement}
          className="relative w-72 h-72 rounded-full bg-slate-900 border-[14px] border-slate-800/90 flex flex-col items-center justify-center shadow-[0_0_80px_rgba(0,0,0,0.6)] active:scale-95 transition-all group overflow-hidden"
        >
          {/* Progress Indicator */}
          <div 
            className="absolute inset-0 rounded-full transition-all duration-300 pointer-events-none opacity-60"
            style={{ 
              background: `conic-gradient(#f59e0b ${((count % goal) / goal) * 100}%, transparent 0%)`,
            }}
          />
          
          <div className="relative z-10 flex flex-col items-center">
            <span className="text-8xl font-black text-white tracking-tighter tabular-nums drop-shadow-2xl">
              {count}
            </span>
            <div className="mt-4 px-4 py-1.5 bg-white/5 rounded-full border border-white/10 backdrop-blur-sm">
               <span className="text-amber-500 text-xs font-black uppercase tracking-[0.2em]">
                Goal: {goal}
              </span>
            </div>
          </div>
          
          <div className="absolute inset-0 rounded-full bg-amber-500/10 opacity-0 group-active:opacity-100 transition-opacity" />
        </button>
        
        <p className="mt-8 text-slate-500 text-xs font-bold uppercase tracking-[0.3em] animate-pulse">Tap to count</p>
      </div>

      {/* Bottom Controls */}
      <div className="p-8 pt-0 flex flex-col gap-6 pb-24">
        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-800/40 backdrop-blur-sm p-4 rounded-3xl border border-white/5 flex flex-col items-center shadow-lg">
            <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Session</p>
            <p className="text-white text-2xl font-black tabular-nums">{sessionTotal}</p>
          </div>
          
          {/* Enhanced Reset Button */}
          <button
            onClick={handleReset}
            className="bg-slate-800/40 backdrop-blur-sm p-4 rounded-3xl border border-white/5 flex flex-col items-center justify-center shadow-lg hover:bg-red-500/10 hover:border-red-500/30 group transition-all active:scale-95"
          >
            <svg className="w-6 h-6 text-slate-500 group-hover:text-red-500 mb-1 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            <p className="text-slate-500 group-hover:text-red-500 text-[10px] font-black uppercase tracking-widest transition-colors">Reset</p>
          </button>
        </div>

        {/* Quick Goal Selector */}
        <div className="flex gap-2">
          {[33, 100, 1000].map(g => (
            <button
              key={g}
              onClick={() => setGoal(g)}
              className={`flex-1 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                goal === g 
                  ? 'bg-white text-slate-900 border-white shadow-xl scale-105' 
                  : 'bg-slate-800/50 text-slate-500 border-white/5'
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>
      
      <style>{`
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .tabular-nums {
          font-variant-numeric: tabular-nums;
        }
      `}</style>
    </div>
  );
};

export default Tasbih;
