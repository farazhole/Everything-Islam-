
import React, { useState, useEffect } from 'react';
import { UserProfile, AppView, BookmarkedAyah } from '../types';

interface Props {
  user: UserProfile;
  onNavigate: (view: AppView, id?: any) => void;
}

const HomeScreen: React.FC<Props> = ({ user, onNavigate }) => {
  const [bookmarks, setBookmarks] = useState<BookmarkedAyah[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('bookmarks');
    if (saved) {
      setBookmarks(JSON.parse(saved));
    }
  }, []);

  const removeBookmark = (e: React.MouseEvent, bMark: BookmarkedAyah) => {
    e.stopPropagation();
    const newBookmarks = bookmarks.filter(b => !(b.surahNumber === bMark.surahNumber && b.ayahNumberInSurah === bMark.ayahNumberInSurah));
    setBookmarks(newBookmarks);
    localStorage.setItem('bookmarks', JSON.stringify(newBookmarks));
  };

  return (
    <div className="p-6 h-full flex flex-col space-y-8 animate-fadeIn overflow-y-auto pb-32">
      <div className="space-y-1">
        <h2 className="text-2xl font-bold text-white">Assalamu Alaikum, {user.name}</h2>
        <p className="text-slate-400">How can we help you today?</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Quran Module */}
        <button
          onClick={() => onNavigate('quran_list')}
          className="group relative h-40 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-6 flex flex-col justify-between overflow-hidden shadow-xl transform active:scale-95 transition-all"
        >
          <div className="z-10 text-left text-white">
            <h3 className="text-2xl font-bold">The Holy Quran</h3>
            <p className="text-emerald-50/80 text-sm mt-1">Recite and explore Divine verses</p>
          </div>
          <div className="z-10 flex justify-between items-end text-white">
            <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm">
              Read Now
            </span>
            <svg className="w-10 h-10 opacity-80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-white/10 rounded-full group-hover:scale-110 transition-transform duration-500" />
        </button>

        {/* Islamic Stories / History (Tarikh) Module */}
        <button
          onClick={() => onNavigate('history')}
          className="group relative h-40 bg-gradient-to-br from-sky-500 to-blue-600 rounded-3xl p-6 flex flex-col justify-between overflow-hidden shadow-xl transform active:scale-95 transition-all"
        >
          <div className="z-10 text-left text-white">
            <h3 className="text-2xl font-bold">Islamic History</h3>
            <p className="text-sky-50/80 text-sm mt-1">Explore stories of Prophets & Sahaba</p>
          </div>
          <div className="z-10 flex justify-between items-end text-white">
            <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm">
              Read Stories
            </span>
            <svg className="w-10 h-10 opacity-80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-white/10 rounded-full group-hover:scale-110 transition-transform duration-500" />
        </button>

        {/* AI Assistant Module */}
        <button
          onClick={() => onNavigate('ai_assistant')}
          className="group relative h-40 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-3xl p-6 flex flex-col justify-between overflow-hidden shadow-xl transform active:scale-95 transition-all"
        >
          <div className="z-10 text-left text-white">
            <h3 className="text-2xl font-bold">Islamic AI</h3>
            <p className="text-indigo-50/80 text-sm mt-1">Ask questions and learn</p>
          </div>
          <div className="z-10 flex justify-between items-end text-white">
            <span className="bg-indigo-400/30 px-3 py-1 rounded-full text-xs font-medium border border-indigo-400/50">
              Open Chat
            </span>
            <svg className="w-10 h-10 opacity-80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
          <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-white/10 rounded-full group-hover:scale-110 transition-transform duration-500" />
        </button>

        {/* Islamic Quiz Module */}
        <button
          onClick={() => onNavigate('quiz')}
          className="group relative h-40 bg-gradient-to-br from-rose-500 to-fuchsia-600 rounded-3xl p-6 flex flex-col justify-between overflow-hidden shadow-xl transform active:scale-95 transition-all"
        >
          <div className="z-10 text-left text-white">
            <h3 className="text-2xl font-bold">Islamic Quiz</h3>
            <p className="text-rose-50/80 text-sm mt-1">Test your knowledge & win points</p>
          </div>
          <div className="z-10 flex justify-between items-end text-white">
            <span className="bg-rose-400/30 px-3 py-1 rounded-full text-xs font-medium border border-rose-400/50">
              Play Now
            </span>
            <svg className="w-10 h-10 opacity-80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
          <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-white/10 rounded-full group-hover:scale-125 transition-transform duration-700" />
          <div className="absolute top-2 right-4 text-white/10 transform rotate-12 scale-150">
             <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24">
               <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14l-5-4.87 6.91-1.01L12 2z"/>
             </svg>
          </div>
        </button>

        {/* Tasbih Module */}
        <button
          onClick={() => onNavigate('tasbih')}
          className="group relative h-40 bg-gradient-to-br from-amber-500 to-orange-600 rounded-3xl p-6 flex flex-col justify-between overflow-hidden shadow-xl transform active:scale-95 transition-all"
        >
          <div className="z-10 text-left text-white">
            <h3 className="text-2xl font-bold">Digital Tasbih</h3>
            <p className="text-amber-50/80 text-sm mt-1">Keep track of your Dhikr</p>
          </div>
          <div className="z-10 flex justify-between items-end text-white">
            <span className="bg-amber-400/30 px-3 py-1 rounded-full text-xs font-medium border border-amber-400/50">
              Start Dhikr
            </span>
            <svg className="w-10 h-10 opacity-80" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-white/10 rounded-full group-hover:scale-110 transition-transform duration-500" />
        </button>
      </div>

      {/* Bookmarked Ayahs Section */}
      {bookmarks.length > 0 && (
        <div className="pt-4 animate-slideUp">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Bookmarked Ayahs</h4>
            <span className="bg-purple-500/20 text-purple-400 text-[10px] px-2 py-0.5 rounded-full font-bold">
              {bookmarks.length} Saved
            </span>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
            {bookmarks.map((b, idx) => (
              <div 
                key={idx}
                onClick={() => onNavigate('quran_reader', b.surahNumber)}
                className="flex-shrink-0 w-64 bg-slate-800/50 border border-white/5 p-4 rounded-2xl relative group cursor-pointer hover:bg-slate-800 transition-colors"
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="text-[10px] font-bold text-purple-400 uppercase tracking-tighter">
                    Surah {b.surahName.replace('سُورَةُ ', '')} • {b.ayahNumberInSurah}
                  </div>
                  <button 
                    onClick={(e) => removeBookmark(e, b)}
                    className="text-slate-500 hover:text-red-400 p-1"
                  >
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                <p className="quran-font text-white text-lg line-clamp-2 leading-tight">
                  {b.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="pt-4 border-t border-white/5">
        <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">Quick Stats</h4>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-800/50 p-4 rounded-2xl border border-white/5 shadow-md">
            <p className="text-orange-400 text-xs font-bold uppercase tracking-tight">Level</p>
            <p className="text-white text-lg font-bold">{user.level}</p>
          </div>
          <div className="bg-slate-800/50 p-4 rounded-2xl border border-white/5 shadow-md">
            <p className="text-blue-400 text-xs font-bold uppercase tracking-tight">Daily Goal</p>
            <p className="text-white text-lg font-bold">15 Ayahs</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
