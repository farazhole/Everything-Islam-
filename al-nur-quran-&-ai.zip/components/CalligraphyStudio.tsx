
import React, { useRef, useState, useEffect } from 'react';
import { generateCalligraphyArt } from '../services/geminiService';

interface Props {
  onBack: () => void;
}

const CalligraphyStudio: React.FC<Props> = ({ onBack }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.lineCap = 'round';
        ctx.lineWidth = 5;
        ctx.strokeStyle = '#ffffff';
        // Fill black background for better AI interpretation
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
    }
  }, []);

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx?.beginPath();
    }
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e ? e.touches[0].clientX : e.clientX) - rect.left;
    const y = ('touches' in e ? e.touches[0].clientY : e.clientY) - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
    }
    setResultImage(null);
  };

  const handleGenerate = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    setLoading(true);
    const base64 = canvas.toDataURL('image/png');
    const art = await generateCalligraphyArt(base64);
    if (art) {
      setResultImage(art);
    } else {
      alert("Khataati generate karne mein masla hua. Dubara koshish karein.");
    }
    setLoading(false);
  };

  return (
    <div className="h-full flex flex-col bg-[#0b1120] animate-fadeIn">
      {/* Header */}
      <div className="p-6 border-b border-white/5 flex items-center justify-between bg-slate-900/50 backdrop-blur-md">
        <div>
          <h2 className="text-2xl font-bold text-white">Calligraphy Studio</h2>
          <p className="text-fuchsia-400 text-[10px] font-black uppercase tracking-widest">فنِ خطاطی</p>
        </div>
        <button 
          onClick={onBack}
          className="p-2 hover:bg-white/5 rounded-full text-slate-400 transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 pb-24">
        {!resultImage ? (
          <div className="space-y-6 animate-slideUp">
            <div className="bg-slate-800/40 border-2 border-dashed border-white/10 p-4 rounded-[2rem] text-center">
              <p className="text-slate-400 text-sm mb-4">Apna naam ya koi lafz (Hindi/English) niche likhein:</p>
              <canvas
                ref={canvasRef}
                width={340}
                height={340}
                onMouseDown={startDrawing}
                onMouseUp={stopDrawing}
                onMouseMove={draw}
                onTouchStart={startDrawing}
                onTouchEnd={stopDrawing}
                onTouchMove={draw}
                className="w-full aspect-square bg-black rounded-2xl cursor-crosshair shadow-2xl border border-white/5"
              />
            </div>

            <div className="flex gap-4">
              <button 
                onClick={clearCanvas}
                className="flex-1 py-4 bg-slate-800 text-slate-400 font-bold rounded-2xl border border-white/5 active:scale-95 transition-all"
              >
                Clear Canvas
              </button>
              <button 
                onClick={handleGenerate}
                disabled={loading}
                className={`flex-1 py-4 font-black rounded-2xl shadow-xl transition-all active:scale-95 flex items-center justify-center gap-2 ${loading ? 'bg-slate-700 text-slate-500 cursor-not-allowed' : 'bg-gradient-to-r from-fuchsia-600 to-purple-600 text-white shadow-fuchsia-500/20'}`}
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <span>✨ Generate Art</span>
                  </>
                )}
              </button>
            </div>

            <div className="bg-fuchsia-500/10 border border-fuchsia-500/20 p-4 rounded-2xl flex items-start gap-3">
              <div className="text-xl">💡</div>
              <p className="text-fuchsia-200 text-xs leading-relaxed">
                Aapki likhai ko AI ek behtareen 3D glowing art mein badal dega jisme phool aur titliyan (flowers & butterflies) bhi hongi.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-fadeIn">
            <div className="bg-slate-900 border border-white/10 rounded-[2.5rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] p-2">
              <img 
                src={resultImage} 
                alt="AI Generated Calligraphy" 
                className="w-full h-auto rounded-[2rem]"
              />
            </div>

            <div className="flex flex-col gap-4">
               <button 
                onClick={() => setResultImage(null)}
                className="w-full py-5 bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-black rounded-[2rem] shadow-xl shadow-blue-500/20 active:scale-95 transition-all"
              >
                Ek Aur Banayein
              </button>
              <div className="flex gap-4">
                <button 
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = resultImage;
                    link.download = 'AlNur-Calligraphy.png';
                    link.click();
                  }}
                  className="flex-1 py-4 bg-slate-800 text-white font-bold rounded-2xl border border-white/10 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  <span>Download</span>
                </button>
                <button 
                  onClick={async () => {
                    if (navigator.share) {
                      try {
                        const blob = await (await fetch(resultImage)).blob();
                        const file = new File([blob], 'calligraphy.png', { type: 'image/png' });
                        await navigator.share({
                          files: [file],
                          title: 'My Islamic Calligraphy Art',
                          text: 'Check out this beautiful art I made in Al-Nur app!',
                        });
                      } catch (err) { console.error(err); }
                    }
                  }}
                  className="flex-1 py-4 bg-slate-800 text-white font-bold rounded-2xl border border-white/10 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                  </svg>
                  <span>Share</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {loading && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
           <div className="w-24 h-24 mb-8">
              <svg className="w-full h-full text-fuchsia-500 animate-spin" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
           </div>
           <h3 className="text-3xl font-black text-white mb-4 urdu-nastaliq leading-relaxed">خطاطی تیار ہو رہی ہے</h3>
           <p className="text-fuchsia-300 font-medium max-w-xs leading-relaxed">
             AI aapki likhai ko 3D art mein tabdeel kar raha hai... Thoda intezar farmayein.
           </p>
        </div>
      )}
    </div>
  );
};

export default CalligraphyStudio;
