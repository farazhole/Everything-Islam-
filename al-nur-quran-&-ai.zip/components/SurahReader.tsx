
import React, { useEffect, useState, useRef } from 'react';
import { fetchSurahDetail } from '../services/quranApi';
import { SurahDetail, Ayah, BookmarkedAyah } from '../types';

interface Props {
  surahNumber: number;
  onBack: () => void;
}

const SurahReader: React.FC<Props> = ({ surahNumber, onBack }) => {
  const [surah, setSurah] = useState<SurahDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [bookmarks, setBookmarks] = useState<BookmarkedAyah[]>(() => {
    const saved = localStorage.getItem('bookmarks');
    return saved ? JSON.parse(saved) : [];
  });
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      const data = await fetchSurahDetail(surahNumber);
      if (data) setSurah(data);
      setLoading(false);
    };
    loadData();
  }, [surahNumber]);

  const isBookmarked = (ayahNum: number) => 
    bookmarks.some(b => b.surahNumber === surahNumber && b.ayahNumberInSurah === ayahNum);

  const toggleBookmark = (ayah: Ayah) => {
    const newBookmarks = isBookmarked(ayah.numberInSurah)
      ? bookmarks.filter(b => !(b.surahNumber === surahNumber && b.ayahNumberInSurah === ayah.numberInSurah))
      : [...bookmarks, { 
          surahNumber, 
          surahName: surah!.name, 
          ayahNumberInSurah: ayah.numberInSurah, 
          text: ayah.text 
        }];
    setBookmarks(newBookmarks);
    localStorage.setItem('bookmarks', JSON.stringify(newBookmarks));
    
    if ('vibrate' in navigator) {
      navigator.vibrate(50);
    }
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center bg-[#0f172a]">
        <div className="w-12 h-12 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!surah) return null;

  return (
    <div className="h-full flex flex-col bg-[#1e293b] relative">
      {/* Floating Pill Back Button exactly as in screenshot */}
      <div className="absolute top-6 left-6 z-50">
        <button 
          onClick={onBack}
          className="bg-white/95 backdrop-blur-md text-slate-900 px-6 py-3 rounded-full shadow-2xl flex items-center gap-2 font-bold text-sm active:scale-95 transition-transform"
          dir="rtl"
        >
          <span>تمام سورتیں</span>
          <span className="text-lg">⇐</span>
        </button>
      </div>

      {/* Card-based Scrolling List */}
      <div 
        ref={containerRef}
        className="flex-1 overflow-y-auto p-4 pt-24 pb-40 space-y-6 scroll-smooth"
      >
        {/* Surah Title Card */}
        <div className="text-center mb-10 py-6">
           <h2 className="quran-font text-5xl text-white mb-2">{surah.name}</h2>
           <p className="text-slate-400 font-bold tracking-widest uppercase text-xs">{surah.englishNameTranslation}</p>
        </div>

        {/* Individual Ayah Cards */}
        {surah.ayahs.map((ayah) => (
          <div 
            key={ayah.number}
            onClick={() => toggleBookmark(ayah)}
            className={`ayah-card p-8 py-12 flex flex-col items-center justify-center text-center cursor-pointer active:scale-[0.98] transition-all ${isBookmarked(ayah.numberInSurah) ? 'ring-2 ring-yellow-400' : ''}`}
          >
            <p className="quran-font text-white text-4xl leading-[2.5] mb-4 drop-shadow-md">
              {ayah.text}
              <span className="ayah-marker ml-4">﴿{ayah.numberInSurah}﴾</span>
            </p>
            
            {/* Simple bookmark indicator if saved */}
            {isBookmarked(ayah.numberInSurah) && (
              <div className="mt-2 text-yellow-300">
                <svg className="w-6 h-6 inline" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                </svg>
              </div>
            )}
          </div>
        ))}

        {/* Footer */}
        <div className="py-20 text-center opacity-30">
          <div className="w-12 h-1 bg-white mx-auto rounded-full mb-4"></div>
          <p className="text-white text-[10px] font-black tracking-widest uppercase">End of {surah.englishName}</p>
        </div>
      </div>
    </div>
  );
};

export default SurahReader;