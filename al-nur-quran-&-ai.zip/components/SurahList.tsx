
import React, { useEffect, useState } from 'react';
import { fetchSurahs } from '../services/quranApi';
import { Surah } from '../types';

interface Props {
  onSurahSelect: (number: number) => void;
}

const SurahList: React.FC<Props> = ({ onSurahSelect }) => {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const loadSurahs = async () => {
      const data = await fetchSurahs();
      setSurahs(data);
      setLoading(false);
    };
    loadSurahs();
  }, []);

  const filteredSurahs = surahs.filter(s => 
    s.englishName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.name.includes(searchTerm) ||
    s.number.toString() === searchTerm
  );

  // Color palette matching the provided image
  const colors = [
    'bg-red-500', 
    'bg-pink-500', 
    'bg-blue-500', 
    'bg-yellow-500', 
    'bg-emerald-500', 
    'bg-purple-500', 
    'bg-orange-500', 
    'bg-green-500', 
    'bg-cyan-500',
    'bg-indigo-500'
  ];

  if (loading) {
    return (
      <div className="p-4 grid grid-cols-3 gap-3">
        {[...Array(15)].map((_, i) => (
          <div key={i} className="animate-pulse aspect-[4/3] bg-slate-800 rounded-2xl"></div>
        ))}
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col animate-fadeIn bg-[#0f172a]">
      {/* Search bar styled for dark theme */}
      <div className="p-4">
        <div className="relative">
          <input
            type="text"
            placeholder="تلاش کریں..."
            className="w-full pl-10 pr-4 py-2.5 rounded-full bg-slate-800/50 border border-white/10 text-white placeholder-slate-500 focus:ring-2 focus:ring-purple-500 outline-none transition-all text-right"
            dir="rtl"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <svg className="absolute left-4 top-2.5 w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 grid grid-cols-3 gap-3 pb-24">
        {filteredSurahs.map((surah, index) => {
          const colorClass = colors[index % colors.length];
          return (
            <button
              key={surah.number}
              onClick={() => onSurahSelect(surah.number)}
              className={`${colorClass} aspect-[4/3] rounded-2xl flex items-center justify-center p-2 shadow-lg shadow-black/20 transform active:scale-95 transition-all hover:brightness-110 group`}
            >
              <div className="text-center">
                <span className="quran-font text-white text-lg leading-tight block drop-shadow-md">
                  سورة {surah.name.replace('سُورَةُ ', '')}
                </span>
                {/* English name can be a subtitle if needed, but the image only shows Arabic */}
                <span className="text-[8px] text-white/60 font-medium uppercase tracking-tighter hidden group-hover:block transition-all">
                   {surah.englishName}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default SurahList;
