
import React, { useState, useRef, useEffect } from 'react';
import { getIslamicAiResponse } from '../services/geminiService';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

type LanguageOption = {
  id: string;
  name: string;
  native: string;
};

const languages: LanguageOption[] = [
  { id: 'Urdu', name: 'Urdu', native: 'اردو' },
  { id: 'Hindi', name: 'Hindi', native: 'हिन्दी' },
  { id: 'Roman Hindi/Urdu', name: 'Roman', native: 'Abc' },
  { id: 'English', name: 'English', native: 'EN' },
  { id: 'Arabic', name: 'Arabic', native: 'العربية' },
];

const AiAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedLang, setSelectedLang] = useState<LanguageOption>(languages[0]);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    const history = messages.map(m => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }]
    }));

    const response = await getIslamicAiResponse(userMessage, selectedLang.id, history);

    if (response) {
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } else {
      setMessages(prev => [...prev, { role: 'assistant', content: "Mafi kijiye, kuch masla hua. Dubara koshish karein." }]);
    }
    setLoading(false);
  };

  return (
    <div className="h-full flex flex-col bg-[#0b1120] animate-fadeIn relative overflow-hidden">
      {/* Language Selector Header */}
      <div className="absolute top-4 right-4 z-30">
        <div className="relative">
          <button 
            onClick={() => setShowLangMenu(!showLangMenu)}
            className="bg-white/10 backdrop-blur-lg border border-white/20 text-white px-4 py-2 rounded-full flex items-center gap-2 text-xs font-bold shadow-xl transition-all active:scale-95"
          >
            <span className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></span>
            {selectedLang.native}
            <svg className={`w-4 h-4 transition-transform ${showLangMenu ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          
          {showLangMenu && (
            <div className="absolute top-12 right-0 w-40 bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-40 animate-fadeIn">
              {languages.map(lang => (
                <button
                  key={lang.id}
                  onClick={() => {
                    setSelectedLang(lang);
                    setShowLangMenu(false);
                  }}
                  className={`w-full text-right px-4 py-3 text-sm hover:bg-white/5 transition-colors ${selectedLang.id === lang.id ? 'text-indigo-400 font-bold bg-white/5' : 'text-slate-300'}`}
                >
                  {lang.name} ({lang.native})
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 pt-16 space-y-8 pb-32"
      >
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-6 opacity-80">
            <div className="ayah-card p-10 flex flex-col items-center">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-4">
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Islamic AI</h2>
              <p className="text-indigo-100 text-lg max-w-[250px] leading-relaxed">
                Aap Islamic masail par koi bhi sawal puch sakte hain.
              </p>
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div 
            key={i} 
            className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} animate-slideUp`}
          >
            <div 
              className={`ayah-card relative max-w-[90%] p-6 shadow-2xl transition-all ${
                msg.role === 'user' 
                  ? 'bg-slate-800 rounded-tr-none border border-white/5' 
                  : 'bg-purple-700 text-white rounded-tl-none'
              }`}
            >
              {/* Ornate Frame Detail for Assistant Messages */}
              {msg.role === 'assistant' && (
                <div className="absolute top-2 left-2 w-4 h-4 border-t border-l border-white/20 opacity-40"></div>
              )}
              
              <p className={`text-xl leading-relaxed ${msg.role === 'assistant' ? 'quran-font' : 'font-medium'}`} dir="auto">
                {msg.content}
              </p>
              
              <div className={`mt-4 flex items-center gap-1 ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}>
                <span className="text-xs ornate-number opacity-50">
                  {msg.role === 'user' ? 'User' : 'Nur AI'}
                </span>
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="ayah-card bg-purple-800/50 p-6 rounded-tl-none animate-pulse flex gap-2">
              <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-white rounded-full animate-bounce delay-75"></div>
              <div className="w-2 h-2 bg-white rounded-full animate-bounce delay-150"></div>
            </div>
          </div>
        )}
      </div>

      {/* Persistent Input Bar - Styled like a floating card */}
      <div className="absolute bottom-20 left-4 right-4 z-20">
        <div className="bg-slate-900/90 backdrop-blur-xl p-2 rounded-[24px] border border-white/10 shadow-2xl flex items-center gap-2">
          <input
            type="text"
            placeholder="Apna sawal yahan likhein..."
            dir="auto"
            className="flex-1 bg-transparent text-white px-5 py-3 outline-none transition-all placeholder-slate-500 text-lg"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || loading}
            className={`w-12 h-12 flex items-center justify-center rounded-2xl transition-all shadow-lg ${
              !input.trim() || loading 
                ? 'bg-slate-800 text-slate-600' 
                : 'bg-indigo-600 text-white shadow-indigo-500/20 active:scale-90 hover:brightness-110'
            }`}
          >
            <svg className="w-6 h-6 transform rotate-90" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AiAssistant;
