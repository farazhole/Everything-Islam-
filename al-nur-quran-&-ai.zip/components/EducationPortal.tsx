
import React from 'react';
import { UserProfile } from '../types';

interface Props {
  user: UserProfile;
  updateCoins: (amount: number) => void;
  onBack: () => void;
}

const EducationPortal: React.FC<Props> = ({ onBack }) => {
  return (
    <div className="h-full flex flex-col bg-[#0f172a] animate-fadeIn">
      {/* Header */}
      <div className="p-6 border-b border-white/5 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Islamic Education</h2>
        <button 
          onClick={onBack}
          className="p-2 hover:bg-white/5 rounded-full text-slate-400 transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Placeholder for Educational Content */}
        <div className="bg-slate-800/40 border border-white/5 p-8 rounded-[2rem] text-center space-y-4">
          <div className="w-20 h-20 bg-emerald-500/20 rounded-3xl flex items-center justify-center mx-auto mb-2 text-4xl">
            📖
          </div>
          <h3 className="text-xl font-bold text-white">Learning Modules</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Islamic studies, Tajweed basics, and Sunnah learning modules are coming soon to help you deepen your knowledge.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4">
          <div className="bg-slate-800/20 border border-white/5 p-5 rounded-2xl flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center text-2xl">🕌</div>
            <div>
              <h4 className="text-white font-bold">Fiqh Basics</h4>
              <p className="text-slate-500 text-xs">Essential rulings for daily life</p>
            </div>
          </div>

          <div className="bg-slate-800/20 border border-white/5 p-5 rounded-2xl flex items-center gap-4 opacity-60">
            <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center text-2xl">📜</div>
            <div>
              <h4 className="text-white font-bold">Hadith Studies</h4>
              <p className="text-slate-500 text-xs">Selected 40 Hadiths with explanation</p>
            </div>
          </div>
          
          <div className="bg-slate-800/20 border border-white/5 p-5 rounded-2xl flex items-center gap-4 opacity-60">
            <div className="w-12 h-12 bg-amber-500/20 rounded-xl flex items-center justify-center text-2xl">✨</div>
            <div>
              <h4 className="text-white font-bold">Adab & Akhlaq</h4>
              <p className="text-slate-500 text-xs">Islamic manners and character building</p>
            </div>
          </div>
        </div>

        <div className="pt-8 text-center">
          <p className="text-slate-600 text-[10px] uppercase font-bold tracking-widest">More content being added weekly</p>
        </div>
      </div>
    </div>
  );
};

export default EducationPortal;
