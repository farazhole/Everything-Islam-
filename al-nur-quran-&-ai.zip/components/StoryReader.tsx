
import React, { useEffect, useState, useRef } from 'react';
import { fetchIslamicStory } from '../services/geminiService';

interface Props {
  storyTitle: string;
  onBack: () => void;
}

const StoryReader: React.FC<Props> = ({ storyTitle, onBack }) => {
  const [content, setContent] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const synth = window.speechSynthesis;
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    const loadStory = async () => {
      setLoading(true);
      const fullText = await fetchIslamicStory(storyTitle);
      if (fullText) {
        setContent(fullText);
      }
      setLoading(false);
    };
    loadStory();

    // Load voices early to avoid empty list on first click
    if (synth.onvoiceschanged !== undefined) {
      synth.onvoiceschanged = () => synth.getVoices();
    }

    return () => {
      synth.cancel();
    };
  }, [storyTitle]);

  const handleSpeak = () => {
    if (isSpeaking) {
      synth.cancel();
      setIsSpeaking(false);
      return;
    }

    if (!content) return;

    // Split content into smaller chunks if it's very long for better stability on some browsers
    const utterance = new SpeechSynthesisUtterance(content);
    
    // Voice selection logic for Urdu/Hindi
    const voices = synth.getVoices();
    const preferredVoice = voices.find(v => v.lang.toLowerCase().includes('ur')) || 
                           voices.find(v => v.lang.toLowerCase().includes('hi')) ||
                           voices[0];
    
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.rate = 0.85; // Natural pace for story narration
    utterance.pitch = 1.0;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = (event) => {
      console.error('Speech error:', event);
      setIsSpeaking(false);
    };

    utteranceRef.current = utterance;
    synth.speak(utterance);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `واقعہ: ${storyTitle}`,
          text: content,
          url: window.location.href,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      handleCopy();
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    alert('Waqia copy ho gaya!');
  };

  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#0090d8] text-center p-8">
        <div className="w-20 h-20 relative mb-6">
          <div className="absolute inset-0 border-4 border-white/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
        </div>
        <p className="text-white font-bold animate-pulse urdu-nastaliq text-2xl">واقعہ لوڈ ہو رہا ہے...</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#0090d8] relative overflow-hidden animate-fadeIn select-none">
      {/* Top Header Background Blur Effect */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black/10 to-transparent pointer-events-none"></div>

      {/* Back Button */}
      <div className="absolute top-6 left-6 z-20">
        <button 
          onClick={onBack}
          className="bg-white/20 backdrop-blur-xl text-white border border-white/40 p-3 rounded-full shadow-2xl active:scale-90 transition-all hover:bg-white/30"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-8 pt-28 pb-48 space-y-12 flex flex-col items-center text-center scroll-smooth no-scrollbar">
        {/* Title Section */}
        <div className="mb-4 animate-slideDown">
          <h2 className="urdu-nastaliq text-[2.8rem] font-bold text-white leading-[4.5rem] drop-shadow-[0_6px_12px_rgba(0,0,0,0.4)]">
            واقعہ: {storyTitle}
          </h2>
        </div>

        {/* Content Body */}
        <div className="max-w-2xl w-full px-4 animate-fadeIn">
          <p className="urdu-nastaliq text-[2.4rem] text-white leading-[4.8rem] tracking-normal whitespace-pre-line drop-shadow-[0_2px_6px_rgba(0,0,0,0.3)] opacity-95">
            {content}
          </p>
        </div>

        {/* End Decoration */}
        <div className="py-12 opacity-40">
          <div className="w-24 h-1 bg-white mx-auto rounded-full shadow-inner"></div>
        </div>
      </div>

      {/* Action Bar Background Blur */}
      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-black/20 to-transparent pointer-events-none"></div>

      {/* Floating Action Buttons Bottom Bar */}
      <div className="absolute bottom-10 left-0 right-0 flex justify-center items-center gap-10 z-30 px-6">
        
        {/* Suno (Listen) Button - The "Mike" styled Speaker button */}
        <button 
          onClick={handleSpeak}
          title={isSpeaking ? "Rokein" : "Sunein"}
          className={`w-18 h-18 sm:w-20 sm:h-20 rounded-full flex items-center justify-center transition-all shadow-[0_12px_30px_rgba(0,0,0,0.4)] active:scale-90 border-2 ${isSpeaking ? 'bg-rose-500 text-white border-rose-400 animate-pulse' : 'bg-white/15 backdrop-blur-2xl border-white/30 text-white hover:bg-white/25'}`}
        >
          {isSpeaking ? (
             <svg className="w-9 h-9" fill="currentColor" viewBox="0 0 24 24">
               <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
             </svg>
          ) : (
            <svg className="w-9 h-9" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
            </svg>
          )}
        </button>

        {/* Share Button */}
        <button 
          onClick={handleShare}
          title="Doston ko bhejein"
          className="w-16 h-16 rounded-full bg-white/15 backdrop-blur-2xl border-2 border-white/30 text-white flex items-center justify-center shadow-[0_10px_25px_rgba(0,0,0,0.35)] active:scale-90 hover:bg-white/25 transition-all"
        >
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
          </svg>
        </button>

        {/* Copy Button */}
        <button 
          onClick={handleCopy}
          title="Likhai copy karein"
          className="w-16 h-16 rounded-full bg-white/15 backdrop-blur-2xl border-2 border-white/30 text-white flex items-center justify-center shadow-[0_10px_25px_rgba(0,0,0,0.35)] active:scale-90 hover:bg-white/25 transition-all"
        >
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" />
          </svg>
        </button>
      </div>

      <style>{`
        .urdu-nastaliq {
          font-family: 'Noto Nastaliq Urdu', serif;
          direction: rtl;
        }
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-slideDown {
          animation: slideDown 0.6s ease-out forwards;
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fadeIn {
          animation: fadeIn 1s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default StoryReader;
