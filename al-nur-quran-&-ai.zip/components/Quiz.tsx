
import React, { useState, useEffect, useRef } from 'react';
import { fetchDynamicQuizQuestions, GeneratedQuestion } from '../services/quizService';

interface Props {
  coins: number;
  updateCoins: (amount: number) => void;
}

const Quiz: React.FC<Props> = ({ coins, updateCoins }) => {
  const [questions, setQuestions] = useState<GeneratedQuestion[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(4);
  const [timeLeft, setTimeLeft] = useState(15);
  const [showResult, setShowResult] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isGameOver, setIsGameOver] = useState(false);
  const [loading, setLoading] = useState(true);
  
  const timerRef = useRef<number | null>(null);

  // Initial load
  useEffect(() => {
    loadNewQuiz();
  }, []);

  // Timer logic
  useEffect(() => {
    if (!loading && !showResult && !isGameOver) {
      startTimer();
    }
    return () => stopTimer();
  }, [currentIdx, loading]);

  const loadNewQuiz = async () => {
    setLoading(true);
    const data = await fetchDynamicQuizQuestions();
    setQuestions(data);
    setCurrentIdx(0);
    setScore(0);
    setLives(4);
    setShowResult(false);
    setIsGameOver(false);
    setSelectedOption(null);
    setLoading(false);
  };

  const startTimer = () => {
    setTimeLeft(15);
    stopTimer();
    timerRef.current = window.setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const handleTimeOut = () => {
    stopTimer();
    setLives(prev => {
      const newLives = prev - 1;
      if (newLives <= 0) {
        setIsGameOver(true);
      } else {
        setTimeout(() => nextQuestion(), 1000);
      }
      return newLives;
    });
    if ('vibrate' in navigator) navigator.vibrate([100, 50, 100]);
  };

  const handleOptionClick = (idx: number) => {
    if (selectedOption !== null || lives <= 0 || loading) return;
    setSelectedOption(idx);
    stopTimer();
    
    if (idx === questions[currentIdx].correct) {
      setScore(prev => prev + 1);
      if ('vibrate' in navigator) navigator.vibrate(50);
    } else {
      setLives(prev => {
        const newLives = prev - 1;
        if (newLives <= 0) setIsGameOver(true);
        return newLives;
      });
      if ('vibrate' in navigator) navigator.vibrate([100, 50, 100]);
    }

    setTimeout(() => {
      if (lives > 1 || (idx === questions[currentIdx].correct && lives > 0)) {
         nextQuestion();
      }
    }, 1500);
  };

  const nextQuestion = () => {
    if (currentIdx + 1 < questions.length) {
      setCurrentIdx(prev => prev + 1);
      setSelectedOption(null);
    } else {
      setShowResult(true);
    }
  };

  const buyLives = () => {
    if (coins >= 10) {
      updateCoins(-10);
      setLives(2);
      setIsGameOver(false);
      setSelectedOption(null);
      startTimer();
    }
  };

  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#0b1120] p-8 text-center">
        <div className="relative w-24 h-24 mb-6">
          <div className="absolute inset-0 border-4 border-indigo-500/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="absolute inset-4 bg-indigo-500/10 rounded-full flex items-center justify-center">
             <svg className="w-8 h-8 text-indigo-500 animate-pulse" fill="currentColor" viewBox="0 0 24 24">
               <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14l-5-4.87 6.91-1.01L12 2z"/>
             </svg>
          </div>
        </div>
        <h2 className="text-2xl font-black text-white mb-2">Quiz Taiyar Ho Raha Hai...</h2>
        <p className="text-slate-400">AI aapke liye naye aur behtareen sawal dhund raha hai.</p>
      </div>
    );
  }

  if (showResult) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-gradient-to-b from-[#0b1120] to-[#1e293b] p-6 animate-fadeIn">
        <div className="bg-slate-900 border-4 border-emerald-500/30 p-10 rounded-[3rem] shadow-[0_20px_50px_rgba(16,185,129,0.2)] text-center w-full max-w-sm">
          <div className="w-24 h-24 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-emerald-500/50">
             <svg className="w-12 h-12 text-emerald-500" fill="currentColor" viewBox="0 0 24 24">
               <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14l-5-4.87 6.91-1.01L12 2z"/>
             </svg>
          </div>
          <h2 className="text-4xl font-black text-white mb-2">MUBARAK!</h2>
          <p className="text-slate-400 mb-8 text-lg font-medium">Aapne <span className="text-white font-bold">{score} / {questions.length}</span> score kiya!</p>
          
          <button
            onClick={loadNewQuiz}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xl rounded-2xl shadow-xl shadow-emerald-500/20 transition-all active:scale-95 uppercase tracking-widest"
          >
            Naya Quiz Khelein
          </button>
        </div>
      </div>
    );
  }

  if (isGameOver) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#0b1120] p-6 animate-fadeIn">
         <div className="bg-slate-900 border-4 border-rose-500/30 p-10 rounded-[3rem] shadow-2xl text-center w-full max-w-sm">
          <h2 className="text-4xl font-black text-white mb-4">GAME OVER</h2>
          <p className="text-slate-400 mb-8">Aapki sari chances khatam ho gayi hain!</p>
          
          <div className="space-y-4">
             <button
              onClick={buyLives}
              disabled={coins < 10}
              className={`w-full py-5 rounded-2xl font-black flex items-center justify-center gap-3 transition-all active:scale-95 ${coins >= 10 ? 'bg-amber-500 text-slate-900 shadow-xl' : 'bg-slate-800 text-slate-600 grayscale'}`}
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                 <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14l-5-4.87 6.91-1.01L12 2z"/>
               </svg>
              <span>BUX (10 Coins)</span>
            </button>
            <button
              onClick={loadNewQuiz}
              className="w-full py-4 bg-slate-800 text-slate-400 font-bold rounded-2xl transition-all"
            >
              Naya Game Start Karein
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentIdx];

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-[#0b1120] via-[#111827] to-[#1e1b4b] p-6 animate-fadeIn relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-rose-600/10 rounded-full -ml-32 -mb-32 blur-3xl"></div>

      {/* Header Info */}
      <div className="flex items-center justify-between mb-8 z-10">
         <div className="flex gap-1.5">
           {[...Array(4)].map((_, i) => (
             <div key={i} className={`w-6 h-6 flex items-center justify-center ${i < lives ? 'text-rose-500 animate-pulse' : 'text-slate-700'}`}>
                <svg className="w-full h-full" fill="currentColor" viewBox="0 0 24 24">
                   <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                </svg>
             </div>
           ))}
         </div>
         <div className="flex flex-col items-center">
            <div className={`w-14 h-14 rounded-full border-4 flex items-center justify-center transition-colors ${timeLeft < 5 ? 'border-rose-500 bg-rose-500/10' : 'border-indigo-500 bg-indigo-500/10'}`}>
               <span className={`text-2xl font-black ${timeLeft < 5 ? 'text-rose-500 animate-ping' : 'text-white'}`}>{timeLeft}</span>
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 mt-1">Waqt</span>
         </div>
         <div className="px-4 py-1.5 bg-white/5 border border-white/10 rounded-2xl flex flex-col items-center">
            <span className="text-indigo-400 text-[10px] font-black tracking-tighter uppercase">Sawal</span>
            <span className="text-white text-lg font-black leading-none">{currentIdx + 1} / {questions.length}</span>
         </div>
      </div>

      {/* Question Card */}
      <div className="flex-1 flex flex-col justify-center gap-6 z-10">
        <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 p-8 rounded-[2.5rem] shadow-2xl relative animate-slideUp">
          <div className="absolute -top-4 -left-4 w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-black shadow-lg">
             Q
          </div>
          <h3 className="text-2xl font-black text-white text-center leading-relaxed">
            {currentQuestion?.question}
          </h3>
        </div>

        <div className="space-y-3.5">
          {currentQuestion?.options.map((option, idx) => {
            const isSelected = selectedOption === idx;
            const isCorrect = idx === currentQuestion.correct;
            const isWrong = isSelected && !isCorrect;

            let borderColor = 'border-white/5';
            let bgStyle = 'bg-slate-900/60 backdrop-blur-sm';
            let textStyle = 'text-slate-300';
            
            if (selectedOption !== null) {
              if (isCorrect) {
                 borderColor = 'border-emerald-500/60';
                 bgStyle = 'bg-emerald-500/20';
                 textStyle = 'text-emerald-400 font-bold';
              } else if (isWrong) {
                 borderColor = 'border-rose-500/60';
                 bgStyle = 'bg-rose-500/20';
                 textStyle = 'text-rose-400 font-bold';
              }
            } else {
              bgStyle += ' hover:bg-white/5 hover:border-white/20';
            }

            return (
              <button
                key={idx}
                onClick={() => handleOptionClick(idx)}
                disabled={selectedOption !== null}
                className={`w-full p-5 text-left rounded-[1.5rem] border-2 transition-all transform active:scale-[0.97] flex items-center justify-between group ${borderColor} ${bgStyle}`}
              >
                <div className="flex items-center gap-4">
                   <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm border ${selectedOption === null ? 'bg-white/5 border-white/10 text-slate-500' : 'bg-transparent border-current'}`}>
                      {String.fromCharCode(65 + idx)}
                   </div>
                   <span className={`text-lg transition-all ${textStyle}`}>
                    {option}
                  </span>
                </div>
                {selectedOption !== null && isCorrect && (
                  <div className="bg-emerald-500 text-white rounded-full p-1 shadow-lg shadow-emerald-500/30">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                )}
                {selectedOption !== null && isWrong && (
                  <div className="bg-rose-500 text-white rounded-full p-1 shadow-lg shadow-rose-500/30">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mt-8 mb-4 h-2 w-full bg-slate-800/50 rounded-full overflow-hidden z-10">
        <div 
          className="h-full bg-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.5)] transition-all duration-700"
          style={{ width: `${((currentIdx + 1) / questions.length) * 100}%` }}
        />
      </div>
    </div>
  );
};

export default Quiz;
