
import React, { useState } from 'react';
import { IslamicStory } from '../types';

interface Props {
  onStorySelect: (title: string) => void;
}

const stories: IslamicStory[] = [
  // Prophets
  { id: 'p1', title: 'Adam (AS)', urduTitle: 'حضرت آدمؑ', category: 'Prophet' },
  { id: 'p2', title: 'Idris (AS)', urduTitle: 'حضرت ادریسؑ', category: 'Prophet' },
  { id: 'p3', title: 'Nuh (AS)', urduTitle: 'حضرت نوحؑ', category: 'Prophet' },
  { id: 'p4', title: 'Hud (AS)', urduTitle: 'حضرت ہودؑ', category: 'Prophet' },
  { id: 'p5', title: 'Salih (AS)', urduTitle: 'حضرت صالحؑ', category: 'Prophet' },
  { id: 'p6', title: 'Ibrahim (AS)', urduTitle: 'حضرت ابراہیمؑ', category: 'Prophet' },
  { id: 'p7', title: 'Lut (AS)', urduTitle: 'حضرت لوطؑ', category: 'Prophet' },
  { id: 'p8', title: 'Ismail (AS)', urduTitle: 'حضرت اسماعیلؑ', category: 'Prophet' },
  { id: 'p9', title: 'Ishaq (AS)', urduTitle: 'حضرت اسحاقؑ', category: 'Prophet' },
  { id: 'p10', title: 'Yaqub (AS)', urduTitle: 'حضرت یعقوبؑ', category: 'Prophet' },
  { id: 'p11', title: 'Yusuf (AS)', urduTitle: 'حضرت یوسفؑ', category: 'Prophet' },
  { id: 'p12', title: 'Shuayb (AS)', urduTitle: 'حضرت شعیبؑ', category: 'Prophet' },
  { id: 'p13', title: 'Ayyub (AS)', urduTitle: 'حضرت ایوبؑ', category: 'Prophet' },
  { id: 'p14', title: 'Dhul-Kifl (AS)', urduTitle: 'ذوالکفلؑ', category: 'Prophet' },
  { id: 'p15', title: 'Musa (AS)', urduTitle: 'حضرت موسیٰؑ', category: 'Prophet' },
  { id: 'p16', title: 'Harun (AS)', urduTitle: 'حضرت ہارونؑ', category: 'Prophet' },
  { id: 'p17', title: 'Dawud (AS)', urduTitle: 'حضرت داؤدؑ', category: 'Prophet' },
  { id: 'p18', title: 'Sulayman (AS)', urduTitle: 'حضرت سلیمانؑ', category: 'Prophet' },
  { id: 'p19', title: 'Ilyas (AS)', urduTitle: 'حضرت الیاسؑ', category: 'Prophet' },
  { id: 'p20', title: 'Al-Yasa (AS)', urduTitle: 'حضرت الیسعؑ', category: 'Prophet' },
  { id: 'p21', title: 'Yunus (AS)', urduTitle: 'حضرت یونسؑ', category: 'Prophet' },
  { id: 'p22', title: 'Zakariya (AS)', urduTitle: 'حضرت زکریاؑ', category: 'Prophet' },
  { id: 'p23', title: 'Yahya (AS)', urduTitle: 'حضرت یحییٰؑ', category: 'Prophet' },
  { id: 'p24', title: 'Isa (AS)', urduTitle: 'حضرت عیسیٰؑ', category: 'Prophet' },
  { id: 'p25', title: 'Muhammad ﷺ', urduTitle: 'محمد مصطفیٰﷺ', category: 'Prophet' },

  // Angels
  { id: 'a1', title: 'Jibreel (AS)', urduTitle: 'جبرائیلؑ', category: 'Angel' },
  { id: 'a2', title: 'Mikaeel (AS)', urduTitle: 'میکائیلؑ', category: 'Angel' },
  { id: 'a3', title: 'Israfeel (AS)', urduTitle: 'اسرافیلؑ', category: 'Angel' },
  { id: 'a4', title: 'Izraeel (AS)', urduTitle: 'عزرائیلؑ', category: 'Angel' },
  { id: 'a5', title: 'Kiraman Katibeen', urduTitle: 'کراماً کاتبین', category: 'Angel' },
  { id: 'a6', title: 'Munkar & Nakeer', urduTitle: 'منکر و نکیر', category: 'Angel' },
  { id: 'a7', title: 'Malik', urduTitle: 'حضرت مالکؑ', category: 'Angel' },
  { id: 'a8', title: 'Ridwan', urduTitle: 'حضرت رضوانؑ', category: 'Angel' },

  // Sahaba
  { id: 's1', title: 'Abu Bakr Siddiq (RA)', urduTitle: 'ابوبکر صدیقؓ', category: 'Sahaba' },
  { id: 's2', title: 'Umar ibn Khattab (RA)', urduTitle: 'عمر فاروقؓ', category: 'Sahaba' },
  { id: 's3', title: 'Usman ibn Affan (RA)', urduTitle: 'عثمان غنیؓ', category: 'Sahaba' },
  { id: 's4', title: 'Ali ibn Abi Talib (RA)', urduTitle: 'علی المرتضیٰؓ', category: 'Sahaba' },
  { id: 's5', title: 'Bilal ibn Rabah (RA)', urduTitle: 'حضرت بلالؓ', category: 'Sahaba' },
  { id: 's6', title: 'Khadijah (RA)', urduTitle: 'خدیجہ الکبریٰؓ', category: 'Sahaba' },
  { id: 's7', title: 'Aisha (RA)', urduTitle: 'عائشہ صدیقہؓ', category: 'Sahaba' },
  { id: 's8', title: 'Fatimah (RA)', urduTitle: 'فاطمہ زہراؓ', category: 'Sahaba' },
  { id: 's9', title: 'Hasan ibn Ali (RA)', urduTitle: 'امام حسنؓ', category: 'Sahaba' },
  { id: 's10', title: 'Husain ibn Ali (RA)', urduTitle: 'امام حسینؓ', category: 'Sahaba' },
  { id: 's11', title: 'Khalid bin Walid (RA)', urduTitle: 'خالد بن ولیدؓ', category: 'Sahaba' },

  // Auliya
  { id: 'au1', title: 'Abu Hanifa (RA)', urduTitle: 'امام ابوحنیفہؒ', category: 'Auliya' },
  { id: 'au2', title: 'Abdul Qadir Jilani (RA)', urduTitle: 'غوثِ اعظمؒ', category: 'Auliya' },
  { id: 'au3', title: 'Moinuddin Chishti (RA)', urduTitle: 'خواجہ غریب نوازؒ', category: 'Auliya' },
  { id: 'au4', title: 'Nizamuddin Auliya (RA)', urduTitle: 'نظام الدینؒ', category: 'Auliya' },
  { id: 'au5', title: 'Shah Waliullah (RA)', urduTitle: 'شاہ ولی اللہؒ', category: 'Auliya' },
];

const categoryColors = {
  Prophet: 'bg-emerald-600',
  Angel: 'bg-cyan-600',
  Sahaba: 'bg-indigo-600',
  Auliya: 'bg-amber-600',
};

const HistorySection: React.FC<Props> = ({ onStorySelect }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = stories.filter(s => 
    s.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.urduTitle.includes(searchTerm)
  );

  return (
    <div className="h-full flex flex-col bg-[#0f172a] animate-fadeIn">
      {/* Search Header */}
      <div className="p-4 bg-slate-900/40 backdrop-blur-md">
        <div className="relative">
          <input
            type="text"
            placeholder="واقعات تلاش کریں (مثلاً: معراج، ہجرت)"
            className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-slate-800/80 border border-white/10 text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-right text-lg"
            dir="rtl"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && searchTerm.trim()) {
                onStorySelect(searchTerm);
              }
            }}
          />
          <button 
            onClick={() => searchTerm.trim() && onStorySelect(searchTerm)}
            className="absolute left-2 top-2 p-1.5 bg-indigo-600 rounded-xl text-white shadow-lg active:scale-90 transition-transform"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 grid grid-cols-3 gap-3 pb-32">
        {filtered.length > 0 ? (
          filtered.map((story) => (
            <button
              key={story.id}
              onClick={() => onStorySelect(story.title)}
              className={`${categoryColors[story.category]} aspect-square rounded-2xl flex flex-col items-center justify-center p-2 shadow-lg transform active:scale-95 transition-all hover:brightness-110 border border-white/10`}
            >
              <span className="quran-font text-white text-lg leading-tight text-center drop-shadow-md">
                {story.urduTitle.replace('حضرت ', '')}
              </span>
              <span className="text-[7px] text-white/70 font-bold uppercase mt-1 tracking-widest">
                {story.category}
              </span>
            </button>
          ))
        ) : searchTerm.trim() !== '' ? (
          <button
            onClick={() => onStorySelect(searchTerm)}
            className="col-span-3 bg-indigo-600/30 border-2 border-dashed border-indigo-500/50 p-8 rounded-3xl text-center animate-pulse"
          >
            <p className="text-white font-bold text-lg mb-2">"{searchTerm}" کا واقعہ لوڈ کریں</p>
            <p className="text-indigo-300 text-xs">AI کی مدد سے مکمل واقعہ تلاش کیا جائے گا</p>
          </button>
        ) : null}
      </div>
    </div>
  );
};

export default HistorySection;
