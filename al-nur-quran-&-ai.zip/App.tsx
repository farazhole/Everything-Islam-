
import React, { useState, useEffect, useRef } from 'react';
import Onboarding from './components/Onboarding';
import HomeScreen from './components/HomeScreen';
import SurahList from './components/SurahList';
import SurahReader from './components/SurahReader';
import AiAssistant from './components/AiAssistant';
import HistorySection from './components/HistorySection';
import StoryReader from './components/StoryReader';
import Tasbih from './components/Tasbih';
import Quiz from './components/Quiz';
import CalligraphyStudio from './components/CalligraphyStudio';
import { UserProfile, AppView } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [view, setView] = useState<AppView>('home');
  const [selectedSurah, setSelectedSurah] = useState<number | null>(null);
  const [selectedStory, setSelectedStory] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  
  const usageTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('user_profile');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsInitializing(false);
  }, []);

  useEffect(() => {
    if (u6ser) {
      usageTimerRef.current = window.setInterval(() => {
        setUser(prev => {
          if (!prev) return prev;
          const newSeconds = prev.totalSecondsUsed + 1;
          const shouldAwardCoin = newSeconds % 30 === 0;
          const updatedUser = {
            ...prev,
            totalSecondsUsed: newSeconds,
            coins: shouldAwardCoin ? prev.coins + 1 : prev.coins
          };
          localStorage.setItem('user_profile', JSON.stringify(updatedUser));
          return updatedUser;
        });
      }, 1000);
    }
    return () => {
      if (usageTimerRef.current) clearInterval(usageTimerRef.current);
    };
  }, [user !== null]);

  const handleOnboardingComplete = (profileData: any) => {
    const profile: UserProfile = {
        ...profileData,
        coins: 10,
        totalSecondsUsed: 0
    };
    setUser(profile);
    localStorage.setItem('user_profile', JSON.stringify(profile));
  };

  const updateCoins = (amount: number) => {
    setUser(prev => {
      if (!prev) return prev;
      const updatedUser = { ...prev, coins: prev.coins + amount };
      localStorage.setItem('user_profile', JSON.stringify(updatedUser));
      return updatedUser;
    });
  };

  const navigateTo = (newView: AppView, id?: any) => {
    if (newView === 'quran_reader' && id !== undefined) setSelectedSurah(id);
    if (newView === 'story_reader' && id !== undefined) setSelectedStory(id);
    setView(newView);
  };

  if (isInitializing) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-900">
        <div className="animate-pulse text-purple-400 font-semibold text-xl">Loading Al-Nur...</div>
      </div>
    );
  }

  if (!user) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  const isReaderView = view === 'quran_reader' || view === 'story_reader' || view === 'tasbih' || view === 'quiz';

  return (
    <div className="max-w-md mx-auto h-screen bg-[#0f172a] shadow-xl relative overflow-hidden flex flex-col">
      {!isReaderView && view !== 'calligraphy' && (
        <header className="bg-slate-900/50 backdrop-blur border-b border-white/5 px-4 py-3 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            {view !== 'home' && (
              <button 
                onClick={() => navigateTo('home')}
                className="p-1 hover:bg-white/10 rounded-full transition-colors text-white"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
            )}
            <h1 className="text-xl font-bold text-white">
              {view === 'home' && 'Al-Nur'}
              {view === 'quran_list' && 'Surah Index'}
              {view === 'ai_assistant' && 'Islamic AI'}
              {view === 'history' && 'Islamic History'}
            </h1>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-full shadow-sm animate-pulse-slow">
               <svg className="w-4 h-4 text-amber-500" fill="currentColor" viewBox="0 0 24 24">
                 <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14l-5-4.87 6.91-1.01L12 2z"/>
               </svg>
               <span className="text-amber-500 text-xs font-black">{user.coins}</span>
            </div>
          </div>
        </header>
      )}

      {isReaderView && (
        <div className="absolute top-4 left-4 z-50">
           <button 
            onClick={() => {
              if (view === 'tasbih' || view === 'quiz') navigateTo('home');
              else if (view === 'quran_reader') navigateTo('quran_list');
              else if (view === 'story_reader') navigateTo('history');
            }}
            className="bg-white/90 backdrop-blur-md text-slate-800 px-4 py-2 rounded-full shadow-xl flex items-center gap-2 font-bold text-sm active:scale-95 transition-transform"
          >
            <span>←</span> Back
          </button>
        </div>
      )}

      <main className="flex-1 overflow-hidden">
        {view === 'home' && <HomeScreen user={user} onNavigate={navigateTo} />}
        {view === 'quran_list' && <SurahList onSurahSelect={(num) => navigateTo('quran_reader', num)} />}
        {view === 'quran_reader' && selectedSurah && (
          <SurahReader surahNumber={selectedSurah} onBack={() => navigateTo('quran_list')} />
        )}
        {view === 'ai_assistant' && <AiAssistant />}
        {view === 'history' && (
          <HistorySection onStorySelect={(title) => navigateTo('story_reader', title)} />
        )}
        {view === 'story_reader' && selectedStory && (
          <StoryReader storyTitle={selectedStory} onBack={() => navigateTo('history')} />
        )}
        {view === 'tasbih' && <Tasbih />}
        {view === 'quiz' && <Quiz coins={user.coins} updateCoins={updateCoins} />}
        {view === 'calligraphy' && <CalligraphyStudio onBack={() => navigateTo('home')} />}
      </main>

      <nav className="bg-[#0b1120] border-t border-white/5 py-2 px-2 flex justify-around items-center z-40">
        <button onClick={() => navigateTo('quran_list')} className="flex flex-col items-center gap-1 min-w-[64px]">
          <div className={`p-1.5 rounded-xl transition-all ${view === 'quran_list' || view === 'quran_reader' ? 'text-orange-400' : 'text-slate-400'}`}>
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <span className={`text-[10px] font-bold ${view === 'quran_list' || view === 'quran_reader' ? 'text-orange-400' : 'text-slate-500'}`}>قرآن</span>
        </button>

        <button onClick={() => navigateTo('ai_assistant')} className="flex flex-col items-center gap-1 min-w-[64px]">
          <div className={`w-8 h-8 rounded-lg nav-gradient flex items-center justify-center text-white shadow-lg ${view === 'ai_assistant' ? 'ring-2 ring-white/50' : 'opacity-80'}`}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <span className={`text-[10px] font-bold ${view === 'ai_assistant' ? 'text-blue-400' : 'text-slate-500'}`}>Islamic AI</span>
        </button>

        <button onClick={() => navigateTo('home')} className="flex flex-col items-center gap-1 min-w-[64px]">
          <div className={`p-1.5 rounded-xl transition-all ${view === 'home' || view === 'tasbih' || view === 'quiz' ? 'text-white' : 'text-slate-400'}`}>
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
          </div>
          <span className={`text-[10px] font-bold ${view === 'home' || view === 'tasbih' || view === 'quiz' ? 'text-white' : 'text-slate-500'}`}>يوم</span>
        </button>

        <button onClick={() => navigateTo('calligraphy')} className="flex flex-col items-center gap-1 min-w-[64px]">
          <div className={`p-1.5 rounded-xl transition-all ${view === 'calligraphy' ? 'text-fuchsia-400' : 'text-slate-400'}`}>
             <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
            </svg>
          </div>
          <span className={`text-[10px] font-bold ${view === 'calligraphy' ? 'text-fuchsia-400' : 'text-slate-500'}`}>Calligraphy</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
