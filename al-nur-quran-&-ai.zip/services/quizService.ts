
import { GoogleGenAI, Type } from "@google/genai";

export interface GeneratedQuestion {
  question: string;
  options: string[];
  correct: number;
}

export const fetchDynamicQuizQuestions = async (): Promise<GeneratedQuestion[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate 10 unique and challenging Islamic quiz questions in Roman Hindi (Hindi written in English alphabet). Topics should include Quran, Prophets (AS), Sahaba (RA), and Islamic History. Each question must have exactly 4 options and only one correct answer.",
      config: {
        systemInstruction: "You are an Islamic scholar and quiz master. Create a JSON array of 10 objects. Each object must have: 'question' (string in Roman Hindi), 'options' (array of 4 strings in Roman Hindi), and 'correct' (integer index 0-3). Ensure the questions are authentic and diverse. Avoid repeating common basic questions.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { 
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              correct: { type: Type.INTEGER }
            },
            required: ["question", "options", "correct"]
          }
        }
      },
    });

    const text = response.text;
    if (text) {
      return JSON.parse(text);
    }
    throw new Error("Empty response from AI");
  } catch (error) {
    console.error('Error generating quiz:', error);
    // Return fallback questions if API fails
    return [
      {
        question: "Quran Pak me kul kitni Surahs hain?",
        options: ["110", "114", "120", "124"],
        correct: 1
      },
      {
        question: "Sabse pehle Nabi (AS) ka naam kya hai?",
        options: ["Ibrahim (AS)", "Musa (AS)", "Adam (AS)", "Isa (AS)"],
        correct: 2
      }
    ];
  }
};
