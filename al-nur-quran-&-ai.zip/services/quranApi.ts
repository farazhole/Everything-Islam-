
import { Surah, SurahDetail } from '../types';

const BASE_URL = 'https://api.alquran.cloud/v1';

export const fetchSurahs = async (): Promise<Surah[]> => {
  try {
    const response = await fetch(`${BASE_URL}/surah`);
    const data = await response.json();
    if (data.code === 200) {
      return data.data;
    }
    throw new Error('Failed to fetch Surahs');
  } catch (error) {
    console.error('Error fetching surahs:', error);
    return [];
  }
};

export const fetchSurahDetail = async (number: number): Promise<SurahDetail | null> => {
  try {
    // Check local storage first (caching)
    const cached = localStorage.getItem(`surah_${number}`);
    if (cached) {
      return JSON.parse(cached);
    }

    const response = await fetch(`${BASE_URL}/surah/${number}`);
    const data = await response.json();
    if (data.code === 200) {
      localStorage.setItem(`surah_${number}`, JSON.stringify(data.data));
      return data.data;
    }
    throw new Error('Failed to fetch Surah detail');
  } catch (error) {
    console.error('Error fetching surah detail:', error);
    return null;
  }
};
