
import { GoogleGenAI } from "@google/genai";

export const getIslamicAiResponse = async (
  message: string,
  language: string = 'Urdu',
  history: { role: string; parts: { text: string }[] }[] = []
): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    const languageInstruction = `Respond strictly in ${language}. If the user uses a different script (like Roman Hindi/Urdu), reply in that same style/script.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: message }] }
      ],
      config: {
        systemInstruction: `You are a wise and compassionate Islamic AI Assistant. Provide answers based on the Quran, authentic Hadith, and recognized Islamic scholarship. ${languageInstruction} Be respectful, clear, and helpful. Maintain a spiritual and scholarly persona.`,
        temperature: 0.7,
        topP: 0.95,
      },
    });

    return response.text || null;
  } catch (error) {
    console.error('Error fetching Islamic AI response:', error);
    return null;
  }
};

/**
 * Strips markdown symbols like #, *, _, etc. from the text
 */
const cleanMarkdown = (text: string): string => {
  return text
    .replace(/[#*_\-`~>]/g, '') // Remove basic markdown symbols
    .replace(/\[|\]/g, '')      // Remove brackets
    .trim();
};

export const fetchIslamicStory = async (storyTitle: string, language: string = 'Urdu'): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Please narrate the detailed and spiritually uplifting story (Vakia) of ${storyTitle} in ${language}. 
      Focus on key lessons and miracles. Break the text into readable paragraphs. 
      STRICT RULE: Do NOT use any symbols like #, *, _, or - for formatting. 
      STRICT RULE: Do NOT use English abbreviations like (AS) or (RA). Use traditional Urdu honorifics like علیہ السلام or رضی اللہ عنہ.`,
      config: {
        systemInstruction: "You are a master Islamic storyteller. Use authentic sources to narrate stories of Prophets and Sahaba in a way that is engaging. Provide ONLY plain text Urdu. Do not use any Markdown formatting or non-Urdu characters.",
        temperature: 0.8,
      }
    });
    
    const rawText = response.text || null;
    return rawText ? cleanMarkdown(rawText) : null;
  } catch (error) {
    console.error('Error fetching story:', error);
    return null;
  }
};

export const generateCalligraphyArt = async (base64Image: string): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image.split(',')[1],
              mimeType: 'image/png',
            },
          },
          {
            text: `Transform this handwriting/scribble into beautiful 3D stylized digital calligraphy. 
            Style: 3D glossy materials, vibrant colors (purples, pinks, blues), glowing neon backlighting, 
            decorative flowers around the letters, and colorful butterflies. 
            The output should look like a professional 3D art piece with depth and lighting, 
            identical in aesthetic to high-end artistic name typography. 
            Keep the text/word exactly as drawn by the user.`,
          },
        ],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error('Error generating calligraphy:', error);
    return null;
  }
};
