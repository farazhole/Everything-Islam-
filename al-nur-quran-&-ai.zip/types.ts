
export interface UserProfile {
  name: string;
  city: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  coins: number;
  totalSecondsUsed: number;
}

export interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

export interface Ayah {
  number: number;
  text: string;
  numberInSurah: number;
  juz: number;
  manzil: number;
  page: number;
  ruku: number;
  hizbQuarter: number;
}

export interface SurahDetail extends Surah {
  ayahs: Ayah[];
}

export interface BookmarkedAyah {
  surahNumber: number;
  surahName: string;
  ayahNumberInSurah: number;
  text: string;
}

export interface IslamicStory {
  id: string;
  title: string;
  urduTitle: string;
  category: 'Prophet' | 'Sahaba' | 'Angel' | 'Auliya';
}

export type AppView = 'home' | 'quran_list' | 'quran_reader' | 'ai_assistant' | 'history' | 'story_reader' | 'calligraphy' | 'tasbih' | 'quiz';
